"""Version module for pathlesstaken."""

__version__ = "v1.0.2"
